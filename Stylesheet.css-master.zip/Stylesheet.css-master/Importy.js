 @sprict (Api.google.com)
Fuction()
  'Case:hello'
  'Output("")'
  Break;
